
/** *
 * @Materia: Programación V
 * @autor: Brayan Puyol, Ashly Mendieta
 * @date: 10/12/2024
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.*;
import javax.swing.text.DefaultCaret;

public class OperacionesCliente extends JFrame implements ActionListener {

    private JPanel panel;
    private JTextField tfMonto;
    private JButton btnDepositar, btnRetirar, btnEstado, btnSalir;
    private JTextArea txArea;
    private RegistroCuentas cuentas;
    private int id;
    final String HOST = "localhost";
    final int PUERTO = 9999;

    public OperacionesCliente(RegistroCuentas cuentas, int id) {
        this.id = id;
        this.cuentas = cuentas;

        this.setSize(500, 500);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setTitle("Operaciones(cliente)");
        this.setLocationRelativeTo(null); //centrar frame
        this.setResizable(false);
        this.setLayout(new FlowLayout());
        this.setLocationByPlatform(true);

        agregrerPanel();
        getContentPane().add(panel);
        pack();
        configSalir();
    }

    private void agregrerPanel() {
        panel = new JPanel(new BorderLayout());
        panel.setSize(600, 600);

        txArea = new JTextArea();
        txArea.setPreferredSize(new Dimension(400, 300));
        txArea.setEditable(false);

        JScrollPane scrol = new JScrollPane(txArea);
        scrol.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrol.setAutoscrolls(true);
        txArea.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        scrol.setViewportView(txArea);
        DefaultCaret caret = (DefaultCaret) txArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        panel.add(scrol, BorderLayout.CENTER);

        Box box = Box.createVerticalBox();

        btnEstado = new JButton("Estado");
        btnEstado.addActionListener(this);
        box.add(btnEstado);
        box.add(Box.createVerticalStrut(10));

        btnDepositar = new JButton("Depositar");
        btnDepositar.addActionListener(this);
        box.add(btnDepositar);

        box.add(Box.createVerticalStrut(10));

        btnRetirar = new JButton("Retirar");
        btnRetirar.addActionListener(this);
        box.add(btnRetirar);

        box.add(Box.createVerticalStrut(20));

        JLabel monto = new JLabel("Monto:");
        monto.setHorizontalAlignment(SwingConstants.CENTER);
        box.add(monto);

        tfMonto = new JTextField();
        tfMonto.setPreferredSize(new Dimension(100, 30));
        box.add(tfMonto);

        JPanel numPanel = new JPanel();
        numPanel.setLayout(new GridLayout(0, 3));

        JButton [] jb = new JButton[10];
        for (int i = 1; i < 9; i++) {
            jb[i] = new JButton(i+"");
            int n = i;
            jb[i].addActionListener(e -> tfMonto.setText(tfMonto.getText() + n));

            numPanel.add(jb[i]);
        }

        JButton jb0 = new JButton("0");
        jb0.addActionListener(e -> tfMonto.setText(tfMonto.getText() + 0));
//        JButton jbEnter = new JButton("Enter");
        JButton jbClear = new JButton("Clear");
        jbClear.addActionListener(e -> tfMonto.setText(""));

        numPanel.add(jb0);
        numPanel.add(jbClear);
        box.add(numPanel);

        JTextField tfLogs = new JTextField();
        panel.add(tfLogs, BorderLayout.SOUTH);
        panel.add(box, BorderLayout.WEST);
    }

    private void configSalir() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                txArea.setText("Saliendo...\n");
                try {
                    Socket socket = new Socket(HOST, PUERTO);
                    ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                    toServer.writeObject(cuentas);

                    socket.close();
                    toServer.close();

                    txArea.append("Se enviaron correctamente los datos actualizados\n");
                } catch (IOException ex) {
                    txArea.append("error en el envio al servidor");
                }

                setVisible(false);
                dispose();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnEstado) {
            txArea.setText(":::::Estado de cuenta::::::\n");
            txArea.append("nombre\tsaldo\ttipo\n");
            txArea.append(cuentas.arregloCuentas.get(cuentas.getIndice(id)).toString2());
            return;
        }

        if (tfMonto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese un monto para poder relizar la transaccion");
        }

        if (e.getSource() == btnDepositar) {
            Thread hiloDeposita = new Depositar(cuentas, txArea, Double.parseDouble(tfMonto.getText()), id);
            hiloDeposita.start();
            tfMonto.setText("");
        }

        if (e.getSource() == btnRetirar) {
            Thread hiloRetira = new Retirar(cuentas, txArea, Double.parseDouble(tfMonto.getText()), id);
            hiloRetira.start();
            tfMonto.setText("");
        }
    }
}
