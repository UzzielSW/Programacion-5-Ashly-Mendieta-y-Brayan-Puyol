
/** *
 * @Materia: Programación V
 * @autor: Brayan Puyol, Ashly Mendieta
 * @date: 10/12/2024
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Cliente extends JFrame implements ActionListener {

    public static void main(String[] args) {
        Cliente inicio = new Cliente(new RegistroCuentas());
        inicio.setVisible(true);
    }

    final String HOST = "localhost";
    final int PUERTO = 9999;
    private JPanel panel, jPanel;
    private JTextField tfCuenta;
    private JTextField tfClave;
    private JButton btnIngresar;
    RegistroCuentas cuentas;

    public Cliente(RegistroCuentas cuentas) {
        this.cuentas = cuentas;
        setLayout(new CardLayout());

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Banco A&B - Login");
        this.setResizable(false);
        this.setLayout(new FlowLayout());
        this.setLocationByPlatform(true);

        panel = new JPanel();
        BoxLayout ly = new BoxLayout(panel, BoxLayout.Y_AXIS);
        EmptyBorder padding = new EmptyBorder(20, 20, 20, 20);
        panel.setBorder(padding);
        panel.setLayout(ly);

        jPanel = new JPanel();

        add(panel, "Login");

        ComponentesPanel();
        pack();
        this.setLocationRelativeTo(null); //centrar frame
    }

    private void ComponentesPanel() {
        JLabel tituloPanel = new JLabel("Banco A&B", JLabel.CENTER);
        tituloPanel.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 30));
        tituloPanel.setPreferredSize(new Dimension(250, 30));
        tituloPanel.setFont(tituloPanel.getFont().deriveFont(35f));
        panel.add(tituloPanel);

        panel.add(Box.createRigidArea(new Dimension(0, 35)));
        JLabel lbNombre = new JLabel("Numero de Cuenta", JLabel.CENTER);
        lbNombre.setFont(lbNombre.getFont().deriveFont(16f));
        panel.add(lbNombre);

        tfCuenta = new JTextField();
        panel.add(tfCuenta);

        panel.add(Box.createRigidArea(new Dimension(0, 35)));
        JLabel lbSaldo = new JLabel("Clave", JLabel.CENTER);
        lbSaldo.setFont(lbSaldo.getFont().deriveFont(16f));
        panel.add(lbSaldo);

        tfClave = new JTextField("");
        panel.add(tfClave);

        panel.add(Box.createRigidArea(new Dimension(0, 35)));

        btnIngresar = new JButton("Login [i]");
        btnIngresar.setMnemonic('i');
        Color colorbtn = new Color(40, 113, 255); // Rojo;
        btnIngresar.setBackground(colorbtn);
        btnIngresar.setForeground(Color.BLACK);
        btnIngresar.setFont(btnIngresar.getFont().deriveFont(16f));
        btnIngresar.addActionListener(this);
        panel.add(btnIngresar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnIngresar) {

            if (tfCuenta.getText().length() == 0 || tfClave.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Por favor coloque los campos de manera correcta");
                return;
            }

            String clave = tfClave.getText();
            int id = Integer.parseInt(tfCuenta.getText());

            CuentaBancaria enviar = new CuentaBancaria(id, clave);

//            iniciando coneccion con el servidor
            try {
                Socket socket = new Socket(HOST, PUERTO);
                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());

                toServer.writeObject(enviar); //envio cuenta bancaria a verificar al servidor

                enviar = (CuentaBancaria) fromServer.readObject();

                if (enviar.getVerificar()) {
                    this.setVisible(false);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "no se pudo iniciar sesion. ingrese correctamente los valores");
                }

                socket.close();
                toServer.close();
                fromServer.close();

            } catch (IOException ex) {
                System.out.println("Error al recibir/enviar datos");
            } catch (ClassNotFoundException ex) {
                System.out.println("Error al hacer casting");
            }
        }
    }
}
